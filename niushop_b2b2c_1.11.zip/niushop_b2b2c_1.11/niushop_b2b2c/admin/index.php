<?php
 header('Location: ../index.php?s=/admin');

